# Ricenoodle

## Introduction
This is a front-end framework which is to use fastly and easily. It provides many block classes.
You don't need to knock keyboard one by one to make some usual classes, such as margin, padding, border.

## Notice
You need forget it if your sites will run on the old browsers.

## Dependences
* Ruby
* Compass
* Webstorm watcher: `Compasss SCSS`

