# Ricenoodle

## notice
You need forget it if your sites will run on the old browsers.